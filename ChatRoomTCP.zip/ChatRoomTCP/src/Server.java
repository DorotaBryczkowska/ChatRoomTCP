import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Runnable - this class can be passed to threads
public class Server extends JFrame implements Runnable
{
    private ArrayList<ConnectionHandler> connections;                            //List of all the clients
    private ServerSocket server;
    private boolean done;
    private ExecutorService pool;

    public Server()
    {
        connections = new ArrayList<>();
        done=false;
    }

    @Override
    public void run()
    {
        try {
            server = new ServerSocket(9999);
            pool = Executors.newCachedThreadPool();                                 //Pool of threads for short-lived tasks
            while (!done) {
                Socket client = server.accept();
                ConnectionHandler handler = new ConnectionHandler(client);          //New client
                connections.add(handler);                                           //Adding client to the list
                pool.execute(handler);
            }
        } catch (Exception e) {
            shutdown();
        }
    }

    public void broadcast(String message)                                       //Sending a message
    {
        for (ConnectionHandler ch: connections)
        {
            if(ch!=null)
            {
                ch.sendMessage(message);
            }
        }
    }

    public void shutdown()
    {
        try {
            done = true;
            pool.shutdown();
            if (!server.isClosed())
            {
                server.close();
            }
            for(ConnectionHandler ch: connections)
            {
                ch.shutdown();
            }
        }catch (IOException e)
        {
            //ignore
        }
    }

    public class ConnectionHandler implements Runnable //handles client connections
    {
        private Socket client;                   //A socket is an endpoint for communication between two machines.
        private BufferedReader in;               //Input stream reading
        private PrintWriter out;                 //Output stream writer
        private String nickname;


        public ConnectionHandler(Socket client)
        {
            this.client = client;
        }


        @Override
        public void run() {
            try {
                out = new PrintWriter(client.getOutputStream(), true);
                in= new BufferedReader(new InputStreamReader(client.getInputStream()));
                out.println("Type '/help' to see possible commands");
                out.println("Enter your nickname");                                              //Entering nickname

                boolean nickOk=false;
                while(!nickOk) {
                    nickname = in.readLine();
                    nickOk = checkNickname(nickname, nickOk);                                    //Checking nickname
                    if(!nickOk)
                    {
                        out.println("Your nickname cannot contain any spaces or special characters");
                    }
                }

                broadcast(nickname + " joined the chat");

                String message;
                while ((message = in.readLine()) !=null )                                          //MESSAGES
                {
                    if(message.startsWith("/nick "))                                               //Rename
                    {
                        String[] messageSplit = message.split(" ");
                        if(messageSplit.length == 2)
                        {
                            broadcast(nickname + " renamed themselves to: " + messageSplit[1]);
                            nickname = messageSplit[1];
                            out.println("Successfully changed nickname to: " + nickname);
                        }else {
                            out.println("No nickname provided");
                        }
                    }else if (message.startsWith("/quit"))                                        //Leaving
                    {
                        broadcast(nickname + " left the chat");
                        shutdown();
                    }else if(message.startsWith("/help"))
                    {
                        out.println("""
                                Possible commands are:\s
                                '/nick [new nick]' to change your nickname
                                '/quit' to exit the chat""");
                    }else
                    {
                        broadcast(nickname + ": " + message);
                    }
                }
            }catch (IOException e) {
                shutdown();
        }
        }

        static boolean checkNickname(String nick, boolean nickOk)                               //Checking nickname
        {
            Pattern special = Pattern.compile ("[.,/!@#$%&*()_+=|<>?{}\\[\\]~-]");
            Matcher hasSpecial = special.matcher(nick);
            boolean num = !nick.isEmpty() && !nick.contains(" ") && !hasSpecial.find();
            if(num)
            {
                return nickOk=true;
            }
            return nickOk;
        }

        public void sendMessage(String message)
        {
            out.println(message);
        }

        public void shutdown()
        {
            try {
                in.close();
                out.close();
                if (!client.isClosed()) {
                    client.close();
                }
            }catch (IOException e)
            {
                //ignore
            }
        }
    }

    public static void main(String[] args) {
        Server server = new Server();
        server.run();
    }
}

