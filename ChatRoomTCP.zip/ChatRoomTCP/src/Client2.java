import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client2 extends JFrame implements Runnable {

    private Socket client;
    private BufferedReader in;
    private static PrintWriter out;
    private boolean done;

    // LOOKS
    private static JFrame frame;
    private static JTextArea textArea;
    private JTextField messageArea;

    @Override
    public void run() {
        try {
            client = new Socket("127.0.0.1", 9999);
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));

            InputHandler inHandler = new InputHandler();
            Thread thread = new Thread(inHandler);
            thread.start();

            String inMessage;
            while ((inMessage = in.readLine()) != null) {
                System.out.println(inMessage);
                appendToTextArea(inMessage);
            }
        } catch (IOException e) {
            shutdown();
        }
    }

    public void shutdown()
    {
        done = true;
        try {
            in.close();
            out.close();
            if (!client.isClosed()) {
                client.close();
            }
        } catch (IOException e) {
            // ignore
        }
    }

    class InputHandler implements Runnable {

        @Override
        public void run() {
            try {
                BufferedReader inReader = new BufferedReader(new InputStreamReader(System.in));
                while (!done)
                {
                    String message = inReader.readLine();
                    if (message.equals("/quit")) {
                        out.println(message);
                        inReader.close();
                        shutdown();
                    } else {
                        out.println(message);
                    }
                }
            } catch (IOException e) {
                shutdown();
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
        Client2 client = new Client2();
        client.run();
    }

    public static void createAndShowGUI() {
        frame = new JFrame("Chat");
        frame.setSize(520, 490);
        frame.setLayout(null);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Serif",Font.PLAIN, 16));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(0,0,500,400);

        JTextField messageArea = new JTextField();
        messageArea.setBounds(70, 400, 430, 50);
        messageArea.setFont(new Font("Serif", Font.PLAIN, 20));

        frame.add(messageArea);

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        messageArea.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = messageArea.getText();
                if(!messageArea.getText().equals("")){
                    out.println(message);
                    messageArea.setText("");
                }
            }
        });
    }

    private void appendToTextArea(String message) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                textArea.append(message + "\n");
            }
        });
    }
}